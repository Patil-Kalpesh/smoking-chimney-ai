import Contact from '@/components/CommonSection/Contact'
import { Divide } from 'lucide-react'
import React from 'react'

export default function page() {
  return (
<div className='mt-14'>
    <Contact />
    </div>
  )
}
