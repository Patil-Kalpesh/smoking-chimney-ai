import Solutions from '@/components/Solutions'
import React from 'react'

export default function page() {
  return (
    <>
        <Solutions/>
    </>
  )
}
