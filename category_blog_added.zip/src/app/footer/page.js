import React from 'react'
import Footer from '@/components/Footer/index'
export default function page() {
  return (
   <Footer/>
  )
}
