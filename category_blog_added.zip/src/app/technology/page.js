import Technology from '@/components/Technology'
import React from 'react'

export default function page() {
  return (
    <div>
      <Technology/>
    </div>
  )
}
