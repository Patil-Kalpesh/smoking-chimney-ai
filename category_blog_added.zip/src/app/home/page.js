import Hero from '@/components/Hero/Hero'
// import MainPage from '@/components/Hero/MainPage'
import React from 'react'

export default function page() {
  return (
    <div>
      <Hero/>
    {/* <MainPage/> */}
    </div>
  )
}
