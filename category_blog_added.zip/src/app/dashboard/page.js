"use client"
import DashboardLayout from '@/components/Dashboard/DashboardLayout'
import React from 'react'

export default function page() {
  return (
    <DashboardLayout title="Dashboard">
      Welcome to the Dashboard!
    </DashboardLayout>
  );
}
