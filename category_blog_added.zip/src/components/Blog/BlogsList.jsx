import React from 'react'

export default function BlogsList() {
  return (
    <div>BlogsList</div>
  )
}
